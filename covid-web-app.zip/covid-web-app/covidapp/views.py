from django.shortcuts import render
import requests
import json
url = "https://covid-193.p.rapidapi.com/statistics"

headers = {
    'x-rapidapi-host': "covid-193.p.rapidapi.com",
    'x-rapidapi-key': "a793eb9e0cmsh5e4708d99b7c6a2p1b14f4jsn90960045c1ab"
    }

response = requests.request("GET", url, headers=headers).json()


# Create your views here.
def helloworldview(request):
    n = int(response['results'])
    mylisttemp =[]
    for x in range(0,n):
        mylisttemp.append(response['response'][x]['country'])
    mylist = sorted(mylisttemp)
    context = {'mylist': mylist}

    if request.method =="POST":
        selectedcountry = request.POST['selectedcountry']
        for x in range(0,n):
            if selectedcountry == response['response'][x]['country']:
                new = response['response'][x]['cases']['new']
                active = response['response'][x]['cases']['active']
                critical = response['response'][x]['cases']['critical']
                recovered = response['response'][x]['cases']['recovered']
                total = response['response'][x]['cases']['total']
                deaths = int(total) - int(active) - int(recovered)
        context = {'selectedcountry': selectedcountry,'mylist': mylist,'new': new, 'active': active, 'critical': critical, 'recovered': recovered,'total': total, 'deaths': deaths }
        return render(request, 'helloworld.html', context)

    return render(request, 'helloworld.html', context)
